import clases.Persona;
import clases.CuentaBancaria;

public class Aplicacion {
    public static void main(String[] args) {
        // Crear instancias de la clase Persona
        Persona persona1 = new Persona("Hector Fuentes", 23);
        Persona persona2 = new Persona("Natalia Sepulveda", 25);
        Persona persona3 = new Persona("Emilio Espinoza", 23);
        Persona persona4 = new Persona("Matias Garrido", 19);

        // Crear instancias de la clase CuentaBancaria
        CuentaBancaria cuenta1 = new CuentaBancaria(5000, persona1);
        CuentaBancaria cuenta2 = new CuentaBancaria(1200, persona2);
        CuentaBancaria cuenta3 = new CuentaBancaria(8000, persona3);
        CuentaBancaria cuenta4 = new CuentaBancaria(7000, persona4);

        // Realizar operaciones de depósito y retiro
        cuenta1.depositar(1000); // Depositar en la cuenta de Héctor
        cuenta2.retirar(500); // Retirar de la cuenta de Natalia
        cuenta3.depositar(2000); // Depositar en la cuenta de Emilio
        cuenta4.retirar(3000); // Retirar de la cuenta de Emilio

        // Imprimir saldo actual de cada cuenta
        System.out.println("Informacion de cada cuenta despues de las operaciones:");
        cuenta1.despliegaInformacion();
        System.out.println();
        cuenta2.despliegaInformacion();
        System.out.println();
        cuenta3.despliegaInformacion();
        System.out.println();
        cuenta4.despliegaInformacion();
        System.out.println();

        // Ejecutar el método para imprimir información de todas las cuentas
        System.out.println("Informacion de todas las cuentas bancarias:");
        CuentaBancaria.imprimeInformacionDeTodasLasCuentas();
    }
}
