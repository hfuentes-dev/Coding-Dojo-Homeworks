package clases;

import java.util.ArrayList;
import java.util.Random;

public class CuentaBancaria {
    private double saldo;
    private Persona titular;
    private int numeroCuenta;
    private static ArrayList<CuentaBancaria> listaDeCuentasBancarias = new ArrayList<>();

    // Constructor
    public CuentaBancaria(double saldo, Persona titular) {
        this.saldo = saldo;
        this.titular = titular;
        this.numeroCuenta = generarNumeroDeCuenta();
        listaDeCuentasBancarias.add(this); // Agregar la cuenta a la lista de cuentas bancarias
    }

    // Genera un número de cuenta aleatorio de 6 dígitos
    private int generarNumeroDeCuenta() {
        Random random = new Random();
        return 100000 + random.nextInt(900000); // Genera un número de cuenta de 6 dígitos
    }

    // Getters y Setters
    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public Persona getTitular() {
        return titular;
    }

    public void setTitular(Persona titular) {
        this.titular = titular;
    }

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    // Métodos para operar la cuenta
    public void depositar(double monto) {
        saldo += monto;
    }

    public void retirar(double monto) {
        if (saldo >= monto) {
            saldo -= monto;
        } else {
            System.out.println("Fondos insuficientes para retirar " + monto);
        }
    }

    // Método para mostrar información de la cuenta
    public void despliegaInformacion() {
        System.out.println("Numero de cuenta: " + numeroCuenta);
        titular.despliegaInformacion();
        System.out.println("Saldo: $" + saldo);
    }

    // Método estático para imprimir información de todas las cuentas
    public static void imprimeInformacionDeTodasLasCuentas() {
        for (CuentaBancaria cuenta : listaDeCuentasBancarias) {
            cuenta.despliegaInformacion();
            System.out.println("--------------------------");
        }
    }
}
