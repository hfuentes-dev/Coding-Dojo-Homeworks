import clases.Algoritmos;

public class Aplicacion {
    public static void main(String[] args) {
        // Métodos de la clase Algoritmos

        // esPar
        System.out.println("esPar(4): " + Algoritmos.esPar(4)); // true
        System.out.println("esPar(5): " + Algoritmos.esPar(5)); // false

        // esPrimo
        System.out.println("esPrimo(7): " + Algoritmos.esPrimo(7)); // true
        System.out.println("esPrimo(10): " + Algoritmos.esPrimo(10)); // false

        // stringEnReversa
        System.out.println("stringEnReversa('Hola'): " + Algoritmos.stringEnReversa("Hola"));

        // esPalindromo
        System.out.println("esPalindromo('radar'): " + Algoritmos.esPalindromo("radar")); // true
        System.out.println("esPalindromo('hola'): " + Algoritmos.esPalindromo("hola")); // false

        // secuenciaFizzBuzz
        System.out.print("Secuencia FizzBuzz (15): ");
        Algoritmos.secuenciaFizzBuzz(15); // Imprime la secuencia del 1 al 15
    }
}
