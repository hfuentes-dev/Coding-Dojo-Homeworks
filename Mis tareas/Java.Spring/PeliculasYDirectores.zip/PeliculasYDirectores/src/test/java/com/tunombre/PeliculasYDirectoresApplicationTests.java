package com.tunombre;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeliculasYDirectoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
