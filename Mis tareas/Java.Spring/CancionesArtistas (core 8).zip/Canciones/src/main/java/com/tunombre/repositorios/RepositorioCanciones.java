package com.tunombre.repositorios;

import com.tunombre.modelos.Cancion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositorioCanciones extends JpaRepository<Cancion, Long> {
}
