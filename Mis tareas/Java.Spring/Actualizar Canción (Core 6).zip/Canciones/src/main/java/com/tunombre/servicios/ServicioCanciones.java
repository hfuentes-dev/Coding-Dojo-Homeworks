package com.tunombre.servicios;

import com.tunombre.modelos.Cancion;
import com.tunombre.repositorios.RepositorioCanciones;

import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ServicioCanciones {
    
    @Autowired
    private RepositorioCanciones repositorioCanciones;

    public List<Cancion> obtenerTodasLasCanciones() {
        return repositorioCanciones.findAll();
    }

    public Cancion obtenerCancionPorId(Long id) {
        return repositorioCanciones.findById(id).orElse(null);
    }

    public Cancion agregarCancion(@Valid Cancion cancion) {
        return repositorioCanciones.save(cancion);
    }
    
    public Cancion actualizaCancion(Cancion cancion) {
        return repositorioCanciones.save(cancion);
    }

}
